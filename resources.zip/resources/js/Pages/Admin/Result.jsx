import React from 'react';

const Result = () => {
  return (
    <div>
      {/* Recent Bookings and Popular Events */}
      <div className='flex flex-row gap-4 w-full'>
        <p>Hello Result is pending</p>
      </div>
    </div>
  );
};

export default Result;
