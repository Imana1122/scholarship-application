export const inputCss = {
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: '#6B7280', // Border color
      },
    },
    '& .MuiInputLabel-root': {
      color: '#6B7280', // Label color

    },
  };
