export const schoolTypes = [
    { value: 'Secondary School', label: 'Secondary School' },
  ];

export  const schoolCategory = [
    { value: 'Public', label: 'Public' },
    { value: 'Private', label: 'Private' },
    { value: 'Community', label: 'Community' },
  ];
