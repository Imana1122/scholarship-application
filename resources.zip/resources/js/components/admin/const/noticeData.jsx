export const noticeOptions = [
    { value: 'info', label: 'Information' },
    { value: 'error', label: 'Error' },
    { value:'warning', label: 'Warning' },
    { value:'success', label: 'Success' }
  ];
