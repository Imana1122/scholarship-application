export  const roles = [
    { value: 1, label: 'Admin' },
    { value: 2, label: 'Super Admin' },
  ];
