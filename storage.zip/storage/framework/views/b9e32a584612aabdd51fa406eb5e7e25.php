<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title>
        <?php if(Route::is('welcome')): ?>
            Welcome to Itahari Municipality Scholarship Application
        <?php elseif(Route::is('about')): ?>
            About Us
        <?php elseif(Route::is('downloads')): ?>
            Downloads
        <?php elseif(Route::is('contact')): ?>
            Contacts
        <?php elseif(Route::is('scholarship.result')): ?>
            Result
        <?php elseif(Route::is('scholarship.result.check')): ?>
            Result Check
        <?php elseif(Route::is('scholarship.apply')): ?>
            Scholarship Apply
        <?php elseif(Route::is('scholarship.admit-card.request-form')): ?>
            Admit Card Request Form
        <?php elseif(Route::is('scholarship.admit-card')): ?>
            Admit Card
        <?php else: ?>
            Itahari Scholarship Application
        <?php endif; ?>
    </title>
    <link rel="icon" type="image/png" href="/storage/images/logo.png" />

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
  </head>
  <body>
    <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\scholarship-app\resources\views/app.blade.php ENDPATH**/ ?>